<?php

namespace Illuminate\Cache\Events;

class KeyForgotten extends CacheEvent
{
    //
}
