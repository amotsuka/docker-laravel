<?php

namespace Illuminate\Database;

use LogicException;

class LostConnectionException extends LogicException
{
    //
}
